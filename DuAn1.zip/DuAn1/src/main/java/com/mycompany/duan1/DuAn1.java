/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.duan1;

import com.mycompany.duan1.View.Login;
import com.mycompany.duan1.View.MainJFrame;



/**
 *
 * @author Admin
 */
public class DuAn1 {

    public static void main(String[] args) {
       new Login().setVisible(true);
//        new MainJFrame().setVisible(true);
    }
}
